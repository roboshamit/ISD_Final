$(document).ready(function(){
  $('.bxslider').bxSlider({
    mode: 'horizontal',
    auto: true,
});	
});