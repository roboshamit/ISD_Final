<div id='footer'>
			  <div class='footerSub1'>
			       <img class='footer-image' src='images/anao.png'>
				   <p style='color:black; font-size:25px; padding-top:2px; font-weight:bolder;'>Hot Line: THU-FRI, 10AM - 10PM</p>
            	  <p style='color:black; font-size:25px; padding-top:-10px; '>+880 1665989562476</br>+880 1732184542135</p>
			  </div>
			  <div class='footerSub2'>
			    
				<h1>Developers</h1>
				<p style='font-size:20px;'>Sakib Ahmed</br>Shamit Ahmed</br>Sofia Neherin</br>Humayra Alam Nuha</br>Dhaka,Bangladesh-1219</br>Bangladesh</p>
				<p  style='font-size:20px;'><a href='https://www.facebook.com/sawkyieb.khan'>Or click here</a>
				
			  </div>
			  <div class='footerSub2'>
			    
				<h1>Contact us</h1>
				<p style='font-size:20px;'>Sakib019898@gmail.com</br>01989863922</br>Shamit@yahoo.com</br>0173859541256</br>Neherin@outlook.com</br>01989365742</br>RoboAlam@cloud.com</br>01875412987453</p>
				
			  </div>
			  
			</div>
			
	  
</body>
</html> 