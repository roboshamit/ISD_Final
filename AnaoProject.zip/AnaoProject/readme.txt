1.create a database named 'anao' in xampp
2.import database from Database/anao.sql into 'anao'
3.then copy anao2 file to htdocs
4.then browse 'localhost/anao'